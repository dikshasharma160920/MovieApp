const express = require('express');
const app = express();

// Sample data for released movies
const releasedMoviesData = [
  { id: 1, title: 'John Wick 4', status: 'PUBLISHED', genres:['action'],trailer_url:'https://www.youtube.com/watch?v=qEVUtrk8_B4',  duration:'210 min',poster_url:'https://image.tmdb.org/t/p/original/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg',release_date:'12 Feb 2024' ,critics_rating:'5/5', wiki_url:'https://www.wikipedia.org/', artists:[ {"artistid": 2, "first_name": "nasiruddin", "last_name": "shah", "wiki_url":"https://en.wikipedia.org/wiki/Naseeruddin_Shah", "profile_url":"https://wikibio.in/wp-content/uploads/2019/06/Naseeruddin-Shah.jpg", "movies":[]},    {"artistid": 3, "first_name": "rajkumar", "last_name": "rao", "wiki_url":"https://en.wikipedia.org/wiki/Rajkummar_Rao", "profile_url":"https://i1.wp.com/wikifamouspeople.com/wp-content/uploads/2018/09/rajkumar-rao.jpg?fit=768%2C432&ssl=1", "movies":[]},  {"artistid": 5, "first_name": "pankaj", "last_name": "kapoor", "wiki_url":"https://en.wikipedia.org/wiki/Pankaj_Kapur", "profile_url":"https://upload.wikimedia.org/wikipedia/commons/a/ac/Pankaj_Kapur.jpg", "movies":[]}]},
  { id: 2, title: 'Mission Impossible Dead Reackoning part 2',genres:['action'], trailer_url:'https://www.youtube.com/watch?v=avz06PDqDbM', duration:'180 min',status: 'PUBLISHED', poster_url:'https://upload.wikimedia.org/wikipedia/en/e/ed/Mission-_Impossible_%E2%80%93_Dead_Reckoning_Part_One_poster.jpg', release_date:'12 Jan 2024',critics_rating:'5/5',wiki_url:'https://www.wikipedia.org/', artists:[  {"artistid": 1, "first_name": "amitabh", "last_name": "bachchan", "wiki_url":"https://en.wikipedia.org/wiki/Amitabh_Bachchan", "profile_url":"https://wikibio.in/wp-content/uploads/2017/12/Amitabh-Bachchan.jpg", "movies":[]}, {"artistid": 2, "first_name": "nasiruddin", "last_name": "shah", "wiki_url":"https://en.wikipedia.org/wiki/Naseeruddin_Shah", "profile_url":"https://wikibio.in/wp-content/uploads/2019/06/Naseeruddin-Shah.jpg", "movies":[]},]},
  { id: 3, title: 'Sully', genres:['action'], trailer_url:'https://www.youtube.com/watch?v=mjKEXxO2KNE', duration:'165 min', status: 'RELEASED', poster_url:'https://cineprog.de/images/Breite_400px_RGB/p_54899.jpg',release_date:'11 jan 2021' ,critics_rating:'5/5',wiki_url:'https://www.wikipedia.org/', artists:[ {"artistid": 4, "first_name": "shabana", "last_name": "azmi", "wiki_url":"https://en.wikipedia.org/wiki/Shabana_Azmi", "profile_url":"https://upload.wikimedia.org/wikipedia/commons/thumb/0/06/Shabana_Azmi_SFU_honorary_degree_%28cropped%29.jpg/1200px-Shabana_Azmi_SFU_honorary_degree_%28cropped%29.jpg", "movies":[]}]},
  { id: 4, title: 'Ragnarok S3', genres:['action', 'mystery'], trailer_url:'https://www.youtube.com/watch?v=7kSTqNurquY', duration:'165 min', status: 'PUBLISHED', poster_url:'https://m.media-amazon.com/images/M/MV5BODM3NTZkZTUtYzEyYS00NjEyLTg2NjEtNDhlMjYwY2ZkNGUzXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_FMjpg_UX1000_.jpg',release_date:'17 June 2024' ,critics_rating:'4.5/5',wiki_url:'https://www.wikipedia.org/', artists:[  {"artistid": 5, "first_name": "Magne", "last_name": "Ragnarok", "wiki_url":"https://en.wikipedia.org/wiki/Pankaj_Kapur", "profile_url":"https://images.immediate.co.uk/production/volatile/sites/3/2023/09/R305Unit00861Christian-Geisnaes-Cropped-eadec26.jpg", "movies":[]},   {"artistid": 5, "first_name": "Saxa", "last_name": "Ragnarok", "wiki_url":"https://en.wikipedia.org/wiki/Pankaj_Kapur", "profile_url":"https://static.wikia.nocookie.net/ragnarok-netflix/images/d/d6/Theresa_Frostad_Eggesb%C3%B8.jpg", "movies":[]}]},
  { id: 5, title: 'Oppenheimer', genres:['action', 'mystery'], trailer_url:'https://www.youtube.com/watch?v=uYPbbksJxIg', duration:'205 min', status: 'RELEASED', poster_url:'https://m.media-amazon.com/images/M/MV5BMDBmYTZjNjUtN2M1MS00MTQ2LTk2ODgtNzc2M2QyZGE5NTVjXkEyXkFqcGdeQXVyNzAwMjU2MTY@._V1_.jpg',release_date:'17 Sept 2023' ,critics_rating:'9.5/10',wiki_url:'https://www.wikipedia.org/', artists:[ {"artistid": 4, "first_name": "shabana", "last_name": "azmi", "wiki_url":"https://en.wikipedia.org/wiki/Shabana_Azmi", "profile_url":"https://upload.wikimedia.org/wikipedia/commons/thumb/0/06/Shabana_Azmi_SFU_honorary_degree_%28cropped%29.jpg/1200px-Shabana_Azmi_SFU_honorary_degree_%28cropped%29.jpg", "movies":[]},  {"artistid": 5, "first_name": "pankaj", "last_name": "kapoor", "wiki_url":"https://en.wikipedia.org/wiki/Pankaj_Kapur", "profile_url":"https://upload.wikimedia.org/wikipedia/commons/a/ac/Pankaj_Kapur.jpg", "movies":[]}]},

];

app.get('/api/movies', (req, res) => {
  const { status, title, genres, artists, start_date, end_date } = req.query;
  // Filter movies based on the provided query parameters
  let filteredMovies = releasedMoviesData.filter(movie => {
    if (status && movie.status !== status) return false;
    if (title && !movie.title.toLowerCase().includes(title.toLowerCase())) return false;
    if (genres && genres.length > 0) {
      const movieGenres = movie.genres.map(genre => genre.toLowerCase());
      if (!genres.split(',').every(genre => movieGenres.includes(genre.toLowerCase()))) return false;
    }
    if (artists && artists.length > 0) {
      const movieArtists = movie.artists.map(artist => (artist.first_name + ' ' + artist.last_name).toLowerCase());
      if (!artists.split(',').every(artist => movieArtists.includes(artist.toLowerCase()))) return false;
    }
    if (start_date && new Date(movie.release_date) < new Date(start_date)) return false;
    if (end_date && new Date(movie.release_date) > new Date(end_date)) return false;
    return true;
  });

  res.json({ movies: filteredMovies });
});
app.get('/movies', (req, res) => {
  const { status, title, genres, artists, start_date, end_date } = req.query;
  // Filter movies based on the provided query parameters
  let filteredMovies = releasedMoviesData.filter(movie => {
    if (status && movie.status !== status) return false;
    if (title && !movie.title.toLowerCase().includes(title.toLowerCase())) return false;
    if (genres && genres.length > 0) {
      const movieGenres = movie.genres.map(genre => genre.toLowerCase());
      if (!genres.split(',').every(genre => movieGenres.includes(genre.toLowerCase()))) return false;
    }
    if (artists && artists.length > 0) {
      const movieArtists = movie.artists.map(artist => (artist.first_name + ' ' + artist.last_name).toLowerCase());
      if (!artists.split(',').every(artist => movieArtists.includes(artist.toLowerCase()))) return false;
    }
    if (start_date && new Date(movie.release_date) < new Date(start_date)) return false;
    if (end_date && new Date(movie.release_date) > new Date(end_date)) return false;
    return true;
  });

  res.json({ movies: filteredMovies });
});

app.get('/api/movies/:id', (req, res) => {
  const movieId = parseInt(req.params.id); // Get the movie ID from the URL parameters
  const movie = releasedMoviesData.find(movie => movie.id === movieId);
  if (movie) {
    res.json({ movie });
  } else {
    res.status(404).json({ error: 'Movie not found' });
  }
});

const port = process.env.PORT || 8085;

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
